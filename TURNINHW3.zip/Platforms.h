#ifndef MOVEPLATFORM
#define MOVEPLATFORM

#include <SFML/Graphics.hpp>
#include <zmq.hpp>
#include <thread>
#include <mutex>
//header for moving platform
class movingPlatform : public sf::RectangleShape
{
public :
    movingPlatform(const sf::Vector2f& xandy, const sf::Vector2f& position);
    void collidePlatform(const int bounderies, const sf::FloatRect bounds);
    void collidePlatformVert(const int bounderies, const sf::FloatRect bounds);
    void setX(int newVel);
    int getX (); 
    void setY(int newVel);
    int getY ();         
private:
    //speed of moving platform
    float xVel = 1;
    float yVel = 0;

};

//header stationary platform
class landPlatform : public sf::RectangleShape
{
public :

    landPlatform(const sf::Vector2f& xandy, const sf::Vector2f& position);
    void flux( int upDown, const sf::FloatRect bounds);
private :
    //how much a stationary platform fluctuates when under collision from moving platform 
    float fluxVal = 20;
};

//header for playable character
class playableRec : public sf::RectangleShape
{
public :

    playableRec(const sf::Vector2f& xandy, const sf::Vector2f& position);
    bool movement(bool grounded, const sf::FloatRect ground, int64_t timeT);
    void setID(std::string newID);
    void deathZoneY(int bounderies);
    void deathZoneX( const sf::FloatRect bounds);
    std::string getID() const;
    void setSpawnX(float spawinPointX);
    void setSpawnY(float spawinPointY);
    float getSpawnX();
    float getSpawnY();
    void setRecievedTime(int64_t time);
    int64_t getRecievedTime();
    void setConnected(bool status);
    bool getConnected();
private :

    //speed of moving character
    float xCharVel = 3000;
    float yCharVel = 4000;
    float spawninX = 100.0;
    float spawninY = 150.0;
    int64_t recievedTime;
    bool connected = true;
    std::string ID ; 
};

class Timeline {

//header for timeline class
public:
    Timeline(Timeline *anchor, int64_t tic);
    int64_t getTime(); //this can be game or system time implementation
    void pause();
    void unpause();
    void changeTic(int tic); //optional
    bool isPaused(); //optional

private:
    std::mutex m; //if tics can change size and the game is multithreaded
    int64_t start_time; //the time of the *anchor when created
    int64_t elapsed_paused_time;
    int64_t last_paused_time;
    int64_t tic; //units of anchor timeline per step
    bool paused;
    Timeline *anchor; //for most general game time, system library pointer
    int64_t sfTime();

};
#endif