#include "Platforms.h"
#include <iostream>
//constructor for playable character
playableRec :: playableRec(const sf::Vector2f& xandy, const sf::Vector2f& position) : sf::RectangleShape(xandy){
    //moving platform    
    setPosition(position);
     //fill out the color of the shape
    setFillColor(sf::Color(255, 0, 0));
    
}

//function for playable character
//params are for jump function, have not implemented
bool playableRec :: movement(bool grounded, const sf::FloatRect ground, int64_t timeT){
    float movementFactor = float(timeT) / 10000; 
    bool moved = false;
    //physics of playableChar

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
    {

        // A key is pressed: move our character
        float newXPos = getPosition().x - xCharVel * movementFactor;
        setPosition(newXPos, getPosition().y);
        moved = true;
    }
    
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
    {
        // D key is pressed: move our character
        float newXPos = getPosition().x + xCharVel * movementFactor;
        setPosition(newXPos,  getPosition().y);
        moved = true;
        
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
    {
        // W key is pressed: move our character
        float newYPos = getPosition().y - yCharVel * movementFactor;
        setPosition( getPosition().x, newYPos);
        moved = true;
        
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
    {
        // S key is pressed: move our character
        float newYPos = getPosition().y + yCharVel * movementFactor;
        setPosition( getPosition().x, newYPos);
        moved = true;
        
    }

    return moved;
   
}

void playableRec :: deathZoneY(const int bounderies){
    if(getPosition().y >= bounderies){
        setPosition(spawninX, spawninY);
    }
        
}

void playableRec :: deathZoneX(const sf::FloatRect ground){
    if(getGlobalBounds().intersects(ground)){
        setPosition(spawninX, spawninY);
    }
        
}

std::string playableRec :: getID() const{
    return ID;
}

void playableRec :: setID(std::string newID){
    ID = newID;
}

void playableRec :: setSpawnX(float val){
    spawninX = val;
}


void playableRec :: setRecievedTime(int64_t time){
    recievedTime = time;
}
    
void playableRec :: setSpawnY(float val){
    spawninY = val;
}

float playableRec :: getSpawnX(){
    return spawninX;
}

float playableRec :: getSpawnY(){
    return spawninY;
}

int64_t playableRec :: getRecievedTime(){
    return recievedTime;
}

void playableRec :: setConnected(bool status){
    connected = status ;
}

bool playableRec :: getConnected(){
    return connected ;
}