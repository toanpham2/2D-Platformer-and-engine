#include "Platforms.h"
#include <iostream>
//constructor for playable character
playableRec :: playableRec(const sf::Vector2f& xandy, const sf::Vector2f& position) : sf::RectangleShape(xandy){
    //moving platform    
    setPosition(position);
     //fill out the color of the shape
    setFillColor(sf::Color(255, 0, 0));
    
}
//GET REAL TIME
//function for playable character
//params are for jump function, have not implemented
//refracr for manager + handler
void playableRec :: movement(bool grounded, const sf::FloatRect ground, int64_t timeT){
    movementFactor = float(timeT) / 10000; 
   
}


std::string playableRec :: getID() const{
    return ID;
}

void playableRec :: setID(std::string newID){
    ID = newID;
}

void playableRec :: setSpawnX(float val){
    spawninX = val;
}


void playableRec :: setRecievedTime(int64_t time){
    recievedTime = time;
}
    
void playableRec :: setSpawnY(float val){
    spawninY = val;
}

float playableRec :: getSpawnX(){
    return spawninX;
}

float playableRec :: getSpawnY(){
    return spawninY;
}

int64_t playableRec :: getRecievedTime(){
    return recievedTime;
}

void playableRec :: setConnected(bool status){
    connected = status ;
}

bool playableRec :: getConnected(){
    return connected ;
}

float playableRec :: getXVel(){
    return xCharVel;
}

float playableRec :: getYVel(){
    return yCharVel;
}

void playableRec :: setXVel(float val){
    xCharVel = val;
}

void playableRec :: setYVel(float val){
    yCharVel = val;
}

void playableRec ::  setmovementFactor(float val){
    movementFactor = val;
}

float playableRec :: getmovementFactor(){
    return movementFactor;
}

int playableRec :: getLives(){
    return lives;
}

void playableRec :: setLives(int newLives){
    lives = newLives;
}